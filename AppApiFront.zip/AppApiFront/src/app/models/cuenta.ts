export class Cuenta {
    idCuenta: number;
    saldo: number;
    tipoCuenta: string;
}
