import { Cuenta } from './cuenta';

describe('Cuenta', () => {
  it('should create an instance', () => {
    expect(new Cuenta()).toBeTruthy();
  });
});
