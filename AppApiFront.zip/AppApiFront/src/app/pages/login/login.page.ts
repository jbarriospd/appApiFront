import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Persona } from 'src/app/models/persona';
import { GeneralService } from 'src/app/services/general.service';
import { PersonasService } from 'src/app/services/personas.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  user: Persona;
  constructor(private personaService: PersonasService,
              private router: Router,
              private alertCtrl: AlertController,
              private generalService: GeneralService) { }

  ngOnInit() {
    this.user = new Persona();
  }

  login(){
    this.personaService.login(this.user).subscribe(
      async response => {
        if(response === 1){
          this.user.contrasena = "";
          this.generalService.guardarStorage(this.user);
          this.router.navigate(['/principal']);
        }else{
          const alert = await
          this.alertCtrl.create({
            header: 'Login',
            message: 'Datos Incorrectos',
            buttons: ['OK']
          });
          alert.present();
        }
      },
      error => {
        console.log(<any>error);
      }  
    )
  }

}
